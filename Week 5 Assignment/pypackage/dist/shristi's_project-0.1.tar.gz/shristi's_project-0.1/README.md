
A simple math package that provides basic addition and subtraction functions.

 ## Installation

   To install the package, use:

   ```bash
   pip install my_package