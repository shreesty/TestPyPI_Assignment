

def add(a, b):
       """Returns the sum of two numbers."""
       return a + b

def subtract(a, b):
       """Returns the difference of two numbers."""
       return a - b